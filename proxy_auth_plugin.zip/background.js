
            var config = {
                mode: "fixed_servers",
                rules: {
                    singleProxy: {
                        scheme: "http",
                        host: "184.174.28.75",
                        port: parseInt(5090)
                    },
                    bypassList: ["localhost"]
                }
            };

            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

                    function callbackFn(details) {
                    return {
                    authCredentials: {
                    username: "teilcwwn",
                    password: "v0dwwr6f725f"
                }
            };
        }

        chrome.webRequest.onAuthRequired.addListener(
        callbackFn,
        {urls: ["<all_urls>"]},
        ['blocking']
        );
        